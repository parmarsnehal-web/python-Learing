employees = [ 
["EMP001","Amit Patel",25000,"IT"], 
["EMP002","Priya Shah",30000,"HR"], 
["EMP003","Rohit Kumar",-5000,"IT"], 
["EMP004","Neha Joshi",45000,"Finance"], 
["EMP005","",28000,"HR"], 
["EMP006","Raj Mehta",None,"IT"], 
["EMP007","Karan Singh",35000,"Sales"], 
["EMP008","Pooja Patel",0,"Marketing"], 
["EMP009","Amit Patel",25000,"IT"], 
["EMP010","Meena Desai",50000,""], 
 
["EMP011","Riya Sharma",32000,"HR"], 
["EMP012","Vikas Patel",27000,"IT"], 
["EMP013","Sneha Shah",42000,"Finance"], 
["EMP014","Nirav Mehta",39000,"Sales"], 
["EMP015","Anjali Patel",31000,"Marketing"], 
["EMP016","Dhruv Shah",29000,"IT"], 
["EMP017","Krunal Patel",34000,"HR"], 
["EMP018","Jinal Shah",36000,"Finance"], 
["EMP019","Parth Mehta",41000,"Sales"], 
["EMP020","Nidhi Patel",38000,"Marketing"], 
 
["EMP021","Harsh Shah",26000,"IT"], 
["EMP022","Bhavik Patel",27500,"HR"], 
["EMP023","Komal Shah",33000,"Finance"], 
["EMP024","Yash Mehta",37000,"Sales"], 
["EMP025","Mansi Patel",35000,"Marketing"], 
["EMP026","Dev Shah",45000,"IT"],
["EMP027","Isha Patel",48000,"HR"], 
["EMP028","Jay Mehta",29000,"Finance"], 
["EMP029","Kajal Shah",31000,"Sales"], 
["EMP030","Manav Patel",34000,"Marketing"], 

["EMP031","Aarav Shah",30000,"IT"], 
["EMP032","Diya Patel",32000,"HR"], 
["EMP033","Vivaan Mehta",36000,"Finance"], 
["EMP034","Kiara Shah",38000,"Sales"], 
["EMP035","Aditya Patel",42000,"Marketing"], 
["EMP036","Riddhi Shah",27000,"IT"], 
["EMP037","Tushar Mehta",46000,"HR"], 
["EMP038","Pallavi Patel",39000,"Finance"], 
["EMP039","Sagar Shah",35000,"Sales"], 
["EMP040","Hetal Mehta",31000,"Marketing"], 

["EMP041","Amit Patel",25000,"IT"], 
["EMP042","Priya Shah",30000,"HR"], 
["EMP043","",41000,"Finance"], 
["EMP044","Raj Mehta",None,"Sales"], 
["EMP045","Neha Joshi",-10000,"Marketing"], 
["EMP046","Harsh Patel",36000,"IT"], 
["EMP047","Naina Shah",34000,"HR"], 
["EMP048","Vivek Mehta",43000,"Finance"], 
["EMP049","Krisha Patel",39000,"Sales"], 
["EMP050","Devanshi Shah",28000,""], 

["EMP051","Mihir Patel",31000,"IT"], 
["EMP052","Ruchi Shah",33000,"HR"], 
["EMP053","Ankit Mehta",37000,"Finance"], 
["EMP054","Bhumi Patel",40000,"Sales"], 
["EMP055","Chirag Shah",45000,"Marketing"], 
["EMP056","Dhwani Mehta",47000,"IT"], 
["EMP057","Esha Patel",29000,"HR"], 
["EMP058","Falgun Shah",31000,"Finance"], 
["EMP059","Gaurav Mehta",35000,"Sales"], 
["EMP060","Hiral Patel",38000,"Marketing"], 

["EMP061","Ishan Shah",26000,"IT"], 
["EMP062","Janki Patel",28000,"HR"], 
["EMP063","Ketan Mehta",34000,"Finance"], 
["EMP064","Lina Shah",36000,"Sales"], 
["EMP065","Milan Patel",39000,"Marketing"],
["EMP066","Nilesh Shah",42000,"IT"], 
["EMP067","Ojas Mehta",44000,"HR"], 
["EMP068","Pinal Patel",46000,"Finance"], 
["EMP069","Rakesh Shah",30000,"Sales"], 
["EMP070","Sonal Mehta",32000,"Marketing"], 

["EMP071","Tanvi Patel",35000,"IT"], 
["EMP072","Umesh Shah",37000,"HR"], 
["EMP073","Vaibhav Mehta",41000,"Finance"], 
["EMP074","Yamini Patel",43000,"Sales"], 
["EMP075","Zarna Shah",48000,"Marketing"], 
["EMP076","Aakash Mehta",29000,"IT"], 
["EMP077","Bhavna Patel",31000,"HR"], 
["EMP078","Chetan Shah",34000,"Finance"], 
["EMP079","Deepa Mehta",36000,"Sales"], 
["EMP080","Eshan Patel",40000,"Marketing"], 

["EMP081","Farhan Shah",45000,"IT"], 
["EMP082","Geeta Mehta",47000,"HR"], 
["EMP083","Hemal Patel",28000,"Finance"], 
["EMP084","Ila Shah",30000,"Sales"], 
["EMP085","Jigar Mehta",33000,"Marketing"], 
["EMP086","Kush Patel",35000,"IT"], 
["EMP087","Lavina Shah",38000,"HR"], 
["EMP088","Mitesh Mehta",42000,"Finance"], 
["EMP089","Nisha Patel",44000,"Sales"], 
["EMP090","Om Shah",46000,"Marketing"], 

["EMP091","Parul Mehta",27000,"IT"], 
["EMP092","Qadir Patel",29000,"HR"], 
["EMP093","Rina Shah",32000,"Finance"], 
["EMP094","Smit Mehta",35000,"Sales"], 
["EMP095","Tina Patel",39000,"Marketing"], 
["EMP096","Urvashi Shah",41000,"IT"], 
["EMP097","Viral Mehta",45000,"HR"], 
["EMP098","Waseem Patel",47000,"Finance"], 
["EMP099","Yogesh Shah",50000,"Sales"], 
["EMP100","Zeeshan Mehta",52000,"Marketing"], 

["EMP101","Amit Patel",25000,"IT"], 
["EMP102","",None,"HR"], 
["EMP103","Raj Mehta",-7000,"Finance"], 
["EMP104","Pooja Patel",0,"Marketing"], 
["EMP105","Sneha Shah",42000,"Finance"] 
]

# Part A: List Operations 
# Q1. Find the total number of employee records. 
print("Total number employee:-",len(employees))

# Q2. Add a new employee record. ["EMP011", "Riya Sharma", 32000, "HR"] 

employees.append(["EMP011", "Riya Sharma", 32000, "HR"])
print("Add new employee:-",employees)

# Q3. Remove employee EMP008 from the list.

employees.remove(["EMP008","Pooja Patel",0,"Marketing"])
print(employees)

# Q4. Display all employee names only. 
for i in employees:
    print(i[1])

# Q5. Find employees whose salary is greater than ₹30,000. 

for i in employees:
    data=i[2]
    if data is not None and data > 30000:
            print(i[1],"-",data)

# Part B: Data Cleaning Using List
#  Q6.Find records having blank employee names. 
print("blank employee names:-")
for i in employees:
     name=i[1]
     if name=="":
          print(i[0]) 

# Q7. Find records having blank department names. 
print("blank department names :-")
for i in employees:
     dept=i[3]
     if dept=="":
          print(i[0]) 


# Q8. Find records having NULL salary values. 
print("NULL salary values:-")
for i in employees:
     salary=i[2]
     if salary==None:
          print(i[0]) 

# Q9. Find records having negative salary values.    
print("negative salary values:-")       
for i in employees:
     nsalary=i[2]
     if nsalary is not None and nsalary < 0:
          print(i[0])

#   Q10. Replace negative salary with 0. 

print("Replace negative salary values:-")       
for i in employees:
     nsalary=i[2]
     if nsalary is not None and nsalary < 0:
          i[2]=0
print(employees) 

# Q11. Replace NULL salary with average salary of valid employees. 

print("NULL salary with average salary of valid employees:-")
total = 0
count = 0


for i in employees:
    salary = i[2]

    if salary is not None and salary >= 0:
        total += salary
        count += 1

average = total / count


for i in employees:
    if i[2] is None:
        i[2] = average

print(employees)

# Q12. Remove records having blank employee names. 

for i in employees:
    name=i[1]
    if name=="":
        employees.remove(i)
print(employees) 

# Part C: Tuple Operations Convert employee records into tuples.
#  Example: ("EMP001", "Amit Patel", 25000, "IT") 
# Q13. Convert all employee records into tuple format. 

l1=employees
print(employees)
tpl1=tuple(l1)
print(tpl1)

# Q14. Display Employee ID and Name using tuple indexing. 

for i in tpl1:
    print("Id=",i[0],"Name=",i[1])
    
# Q15. Count total tuple records. 


print("Total tuple record:-",len(tpl1))

# Q16. Find highest salary employee using tuples.

max=tpl1[0]

for i in tpl1:
    print(i,end="\t")
    if i[2] is not None and i[2] > max[2]:
        max=i
print("Highest salary = ",max)

# Q17. Find lowest salary employee using tuples. 

min=tpl1[0]

for i in tpl1:
    print(i,end="\t")
    if i[2] is not None and i[2] < min[2]:
        min=i
print("lowest salary = ",min)

# Part D: Set Operations 
# Q18. Create a set of all departments. 

set1={emp[3] for emp in employees}
print(set1)

# Q19. Display unique department names. 

set1={emp[3] for emp in employees}
print(set1)

# Q20. Count total unique departments. 

print(len(set1))

# Q21. Check whether "Finance" department exists or not. 

if "Finance" in set1:
    print("Exists")
else:
    print("Not exists")


# Q22. Add a new department "Administration". 

set1.add("Administration")
print("Add new element:-",set1)

# Q23. Remove "Marketing" department. 

set1.remove("Marketing")
print("Remove department :-",set1)

# Part E: Duplicate Data Cleaning Using Set 
# Q24. Identify duplicate employee names. 


seen = set()
duplicate = set()

for i in employees:
    name = i[1]

    if name in seen:
        duplicate.add(name)
    else:
        seen.add(name)

print(duplicate)

# Q25. Create a set of employee names. 

set1={emp[1] for emp in employees}
print("set employee name:-",set1)

# Q26. Count unique employees. 

print(len(seen))

# Q27. Find duplicate records. Expected Duplicate: "Amit Patel" 


NameSet = set()
duplicates = []

for emp in employees:
    if emp[1] in NameSet:
        duplicates.append(emp)
    else:
        NameSet.add(emp[1])

print("Duplicate Records:", duplicates)
print("Expected Duplicate:", duplicates[0][1])

# Part F: Data Analysis 
# Q28. Calculate total salary expenditure. 

set1={emp[2] for emp in employees}
print(set1)

total=0
for i in set1:
    if i is not None and i > 0:
      total +=i
print("Total salary:-",total)       

# # Q29. Calculate average salary. 

total = 0
count = 0


for i in set1:
    

    if i is not None and i >= 0:
        total += i
        count += 1

average = total / count
print("Average salary:-",average)

# Q30. Find maximum salary. 


filtered_set = {x for x in set1 if x is not None}
print("Maximum salary:-",max(filtered_set))

# # Q31. Find minimum salary. 

filterset={x for x in set1 if x is not None }
print("Minimum salary:-",min(filterset))

# Q32. Count employees department-wise. 
# Example Output:  IT : 3 HR : 2 Finance : 1 Sales : 1 

it=0
hr=0
sales=0
finance=0
marketing=0

for i in employees:
     print(i[3])
     if i[3]=="IT":
         it +=1
     if i[3]=="HR":
         hr +=1
     if i[3]=="Finance":
         finance+=1
     if i[3]=="Sales":
         sales+=1
     if i[3]=="Marketing":
         marketing+=1            
print("")       

print("IT:-",it)
print("HR:-",hr)
print("Finance:-",finance)
print("sales:-",sales)
print("Marketing:-",marketing)

# Part G: Mini Project Employee Data Cleaning Report Perform the following: 
# ✔ Remove duplicate employee names 

set1={emp[1] for emp in employees}
print(set1)

# ✔ Remove blank names 

for i in employees:
    name=i[1]
    if name=="":
        employees.remove(i)
print(employees) 

# ✔ Replace NULL salary with average salary 

print("NULL salary with average salary of valid employees:-")
total = 0
count = 0


for i in employees:
    salary = i[2]

    if salary is not None and salary >= 0:
        total += salary
        count += 1

average = total / count


for i in employees:
    if i[2] is None:
        i[2] = average

print(employees)

# ✔ Replace negative salary with 0 

print("Replace negative salary values:-")       
for i in employees:
     nsalary=i[2]
     if nsalary is not None and nsalary < 0:
          i[2]=0
print(employees) 

# ✔ Replace blank department with "Unknown" 

for i in employees:
     nsalary=i[3]
     if nsalary is not None and nsalary == "":
          i[3]="Unknown"
print(employees) 

# ✔ Display: 
# • Total Employees 
#  • Total Departments  
# • Total Salary  
# • Average Salary  
# • Highest Salary Employee 
#  • Lowest Salary Employee  

# • Total Employees 
print("Total Employee:-")
set1={emp[1] for emp in employees}
print(len(set1))

#  • Total Departments  
set1={emp[3] for emp in employees}
print("Total department:")
print(len(set1))
print(len(employees))

# • Total Salary  
set1={emp[2] for emp in employees}
print(set1)

total=0
for i in set1:
    if i is not None and i > 0:
      total +=i
print("Total salary:-",total) 

# • Average Salary  
total = 0
count = 0


for i in employees:
    salary = i[2]

    if salary is not None and salary >= 0:
        total += salary
        count += 1

average = total / count
print(average)

# • Highest Salary Employee 

filtered_set = {x for x in set1 if x is not None}
print("Maximum salary:-",max(filtered_set))
 
#  • Lowest Salary Employee  

filterset={x for x in set1 if x is not None }
print("Minimum salary:-",min(filterset))
