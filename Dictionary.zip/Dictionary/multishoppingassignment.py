
customerList=[]

CustomerName=int(input("How many customer you want to Add? -"))
print("==========================================================================================")
for j in range(CustomerName):
    grandtotal=0
    shoppingList=[]
    
    print("==========================================================================================")
    Name=input("please Enter Customer Name:-")
    print("==========================================================================================")
    Product=int(input("How many product you want to Add? -"))
    print("==========================================================================================")
    for i in range(Product):
        
        print("==========================================================================================")
        print(f"{i+1}#. ")
        print("==========================================================================================")
        ProductName=input("Please Enter Product Name:-")
        Price=int(input("Please Enter Product Price:-"))
        Qty=int(input("Please Enter Product Qty:-"))
        Total=Price*Qty
        grandtotal += Total
        Discount=grandtotal/10
        NetTotal=grandtotal-Discount
        ShoppingDict ={
            "ProductName":ProductName,
            "Price":Price,
            "Qty":Qty,
            "Total":Total
        }
        shoppingList.append(ShoppingDict)
        customerdist ={
            "Name":Name,
            "ProductName":shoppingList,
            "GrandTotal":grandtotal,
            "Discount":Discount,
            "NetTotal":NetTotal
        }
        customerList.append(customerdist)
for Customer in customerList:        
    print("====================================================================================================")
    print("====================================================================================================")
    print("Customer Name:",Customer['Name'])
    print("====================================================================================================")
    print("====================================================================================================")
    print("No\tName\tPrice\tQty\tTotal")
    print("====================================================================================================")
    count=1
    for singlecustomerDict  in Customer["ProductName"]:
        print(f"{count}",end="\t")
        for value in singlecustomerDict.values():
            print(f"{value}",end="\t")
        count += 1
        print("")    
    print("====================================================================================================")
    print("Grand Total:-",Customer["GrandTotal"])
    print("Discount(10%)=",Customer["Discount"])
    print("Net Total=",Customer["NetTotal"])
    print("Thank for shopping")




