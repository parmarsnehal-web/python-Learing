EmployeeList=[]

EmployeeName=int(input("How Many Employee You Want to Add ? -"))
print("==========================================================================================")
for i in range(EmployeeName):
    print("==========================================================================================")
    print(f"{i+1}#. ")
    print("==========================================================================================")
    EmployeId=int(input("Please Enter Employee Id:-"))
    EmployeeName=input("Please Enter Employee Name:-")
    EmployeeRole=input("Please Enter Employee Role:-")
    Employesalary=int(input("Please Enter Employee salary:-"))
    da=0.5*Employesalary
    Hra=0.1*Employesalary
    medical=0.04*Employesalary
    gross=Employesalary+da+Hra+medical
    pf=0.05*gross
    ins=0.07*gross
    ded=ins+pf
    netsalary=gross-ded

    EmployeeDict={
        "EmployeId":EmployeId,
        "EmployeName":EmployeeName,
        "EmployeRole":EmployeeRole,
        "Employeesalary":Employesalary,
        "DA":da,
        "HRA":Hra,
        "Medical":medical,
        "gsalary":gross,
        "ins":ins,
        "pf":pf,
        "ded":ded,
        "netsalary":netsalary
    }
    EmployeeList.append(EmployeeDict)

print("======================================================================================================================================================")
print("=======================================================================================================================================================")
print("No\tEmpId\tName\tEmpRole\t\t\tB.salary\tDA\tHRA\tMEDICAL\tG.salary\tINSURANCE\tPF\tDeduction\tN.salary")
print("=======================================================================================================================================================")
count=1
for singleEmployeDict in EmployeeList:
    print(f"{count}",end="\t")
    for value in singleEmployeDict.values():
        print(f"{value}",end="\t")
    count+=1
    print("")    
print("=======================================================================================================================================================")
