class student:
    #  student constructor
    def __init__(self):
        self.Rollno=0    #Class property Declaration
        self.Name=""
        # print("Student class call from constructor.")

    def Readdata(self):
        self.Rollno=int(input("Please Enter RollNo:"))
        self.Name=input("Please Enter name:-")

    def showdata(Self):
          print(Self.Rollno,"\t",Self.Name)

    