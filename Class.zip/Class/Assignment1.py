from Assignment1class import Member

print("welcome to use sport membership calculator.")
No=int(input("How Many customer you Want to Add? -"))
MemberList=[]

print("=========================================================================================================================")
for i in range(No):
    print("======================================================================================================================")
    print(f"{i+1}#.")
    print("=======================================================================================================================")
    m=Member()
    m.ReadData()
    print("=======================================================================================================================")
    print("The membership of fee from ",m.Name," is ",m.charge)
    MemberList.append(m)

print("========================================================================================================================================================")
print("Summary of Membership Fee")
print("========================================================================================================================================================")
print("No\tName\tMonths\tSpecialoffer\tCharge")
print("========================================================================================================================================================")
count=1
for singlemember in MemberList:
    print(f"{count}",end="\t")
    singlemember.ShowData()
    count+=1    
print("========================================================================================================================================================")

max=MemberList[0]
min=MemberList[0]
less=0
Greater=0

for i in MemberList:
    # i.ShowData()
    if i.charge > max.charge:
        max=i
    if i.charge < min.charge:
        min=i
    if i.Months < 6:
        less += 1
        print
    else:
        Greater += 1        
  

print("========================================================================================================================================================")
print("The customer spending most is ", max.Name," $",max.charge)
print("The customer spending least is ", min.Name," $",min.charge)

print("========================================================================================================================================================")

print("The number of member with < 6 months = ",end="")
for i in range(less):
    print("x",end=" ")
print()

print("The number of member with >= 6 months = ",end="")
for i in range(Greater):
    print("x",end=" ")
print()     