class Employee:
    def  __init__(self):
        self.Id=0
        self.EmployeName=""
        self.EmployeRole=""
        self.salary=0
        self.DA=0
        self.HRA=0
        self.Medical=0
        self.grosssalary=0
        self.ins=0
        self.pf=0
        self.deduction=0
        self.netsalary=0

    def ReadData(self):
        self.Id=int(input("Please Enter Employe Id:-"))
        self.EmployeName=input("Please Enter Employee Name:-")
        self.EmployeRole=input("Please Enter Employe Role:-")
        self.salary=int(input("Please ENter Employe Basic Salary:-"))
        self.DA=0.5*self.salary
        self.HRA=0.1*self.salary
        self.Medical=0.04*self.salary
        self.grosssalary=self.salary+self.DA+self.HRA+self.Medical
        self.ins=0.7*self.grosssalary
        self.pf=0.5*self.grosssalary
        self.deduction=self.ins+self.pf
        self.netsalary=self.grosssalary-self.deduction

    def  ShowData(self):
        print(self.Id,"\t",self.EmployeName,"\t",self.EmployeRole,"\t",self.salary,"\t",
              self.DA,"\t",self.HRA,"\t",self.Medical,"\t",self.grosssalary,"\t",self.ins,"\t",
              self.pf,"\t",self.deduction,"\t",self.netsalary)
