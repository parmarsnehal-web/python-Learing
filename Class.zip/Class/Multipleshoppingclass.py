class shopping:
    def  __init__(self):
        self.productname=""
        self.price=0
        self.Qty=0
        self.Total=0
        self.Grandtotal=0
        self.Discount=0
        self.NetTotal=0

    def ReadData(self):
        self.productname=input("Please Enter Product Name:-")
        self.price=int(input("Please Enter Product Price:-"))
        self.Qty=int(input("Please Enter Product Qty:-"))
        self.Total=self.price*self.Qty
        

    def  showdata(self):
        print(self.productname,"\t",self.price,"\t",self.Qty,"\t",self.Total)