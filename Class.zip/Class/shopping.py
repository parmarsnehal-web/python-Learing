from Shoppingclass import shopping

Name=input("Please Enter Customer Name:-")
no=int(input("How many products You want to Add?- "))
shoppingList=[]
Grandtotal=0


print("=====================================================================================")

for i in range(no):
    print("================================================================================")
    print(f"{i+1}#.")
    print("================================================================================")
    s=shopping()
    s.ReadData()
    Grandtotal +=s.Total
    Discount = Grandtotal/10
    NetTotal=Grandtotal-Discount
   
    shoppingList.append(s)


print("=====================================================================================")
print("Customer Name :",Name)
print("=====================================================================================")
print("No\tName\tPrice\tQty\tTotal")
print("=====================================================================================")
count=1
for singleshopping in shoppingList:
    print(f"{count}",end="\t")
    singleshopping.showdata()
    count += 1    
print("=====================================================================================")
print("GrandTotal =",Grandtotal)
print("Discount(10%) =",Discount)
print("Net Total =",NetTotal)
print("Thank for shopping.")