from  studentclass import student

no=int(input("How Many Student you want to Add? -"))
studentList=[]

# Object = instant()
# class Intialization
for i in range(no):
    s=student()
    s.Readdata()
    studentList.append(s)

print("==================================================")
print("RollNo\tName")
print("==================================================")
for singlestudent in studentList:
    singlestudent.showdata()

    