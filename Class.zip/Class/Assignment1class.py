class Member:
    def __init__(self):
        self.Name=""
        self.Months=0
        self.Specialoffer=""
        self.charge=0

    def  ReadData(self):
        self.Name=input("Enter Customer Name:")
        
        while True:
                self.Months=int(input("Enter the number of months:"))
                if self.Months<=60:
                    print("Months :",self.Months)
                    break
                else:
                    print("Invalid months")
                    print("Please Re-Enter Months:")     

        if self.Months<=6:
            self.charge=self.Months*30.0
        elif self.Months<=12:
             self.charge=self.Months*27.5
        else:
             self.charge=self.Months*25.0

        self.Specialoffer=input("Enter yes or no to indicate a special offer:")


    def ShowData(self):
        print(self.Name,"\t",self.Months,"\t",self.Specialoffer,"\t",self.charge)      