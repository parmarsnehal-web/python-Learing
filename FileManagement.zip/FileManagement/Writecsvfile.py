import csv

header=["RollNo","Name","Mobile","class"]
data1=[1,"snehal",1234567890,"BCA"]
data2=[2,"Bansi",4567891230,"BCA"]

file = open("student.csv","w")

writer =csv.writer(file)
writer.writerow(header)
writer.writerow(data1)
writer.writerow(data2)

file.close()
print("Your student csv file is successfully created.")
