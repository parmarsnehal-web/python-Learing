import re
class shopping:
    def  __init__(self):
        self.productname=""
        self.price=0
        self.Qty=0
        self.Total=0
        self.Grandtotal=0
        self.Discount=0
        self.NetTotal=0

    def ReadData(self):
        productpattern="^[a-zA-Z\\s]{1,50}$"
        self.productname=input("Please Enter Product Name:-")
        while re.match(productpattern,self.productname) == None:
              print("ProductName is not valid.")  
              self.productname=input("Please Re-Enter your Product name:-")
        print("ProductName is valid.")
        
        self.price=int(input("Please Enter Product Price:-"))
        self.Qty=int(input("Please Enter Product Qty:-"))
        self.Total=self.price*self.Qty
        

    def  showdata(self):
        
        # # create file using python
         file=open("Shopping.txt","a")
         file.write(self.productname)
         file.write("\t")
         file.write(str(self.price))
         file.write("\t")
         file.write(str(self.Qty))
         file.write("\t")
         file.write(str(self.Total))
         file.close()
        #  print("Your file is successfully created.")


          # Read file
         file=open("Shopping.txt","r")
         lines=file.read()
         file.close()
         print(lines)
        #  print("Your file is successfully readed.")