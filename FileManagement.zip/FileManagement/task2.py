 # Create a file using  python

file=open("Even.txt","w")
Even=int(input("Please Enter No:"))
file.write("Even -")
for i in range(2,Even,1):
    if i % 2 == 0:
        file.writelines(str(i))
     
file.close()

print("Your file is successfully created.")

#  Read File
file=open("Even.txt","r")
lines=file.read()
file.close()
print(lines)
print("Your file is successfully readed.")