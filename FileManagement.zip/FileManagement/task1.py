# create a file using python
file=open("Biodata.txt","w")
Name = input("Please Enter your Name:")
Fathername = input("Please Enter your father name:")
MobileNo = input("Please Enter your Mobile no:")
Email = input("Please Enter your Email:")

file.writelines(Name)
file.writelines(Fathername)
file.writelines(MobileNo)
file.writelines(Email)
file.close()

print("Your file is successfully created.")


# Read File
file=open("Biodata.txt","r")
lines=file.read()
file.close()
print(lines)
print("Your file is successfully readed.")
