import csv

# f = open("Indian_Data_10.csv","r")


# csvReadfile = csv.reader(f)

# for line in csvReadfile:
#     print(line)

# f.close()    


f = open("Indian_Data_10.csv","r")


csvReadfile = csv.reader(f)

for line in csvReadfile:
    print(line[0],"\t",line[1],"\t",line[2],"\t",line[3])

f.close()    