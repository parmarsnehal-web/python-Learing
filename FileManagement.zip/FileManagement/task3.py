 # Create a file using  python

file=open("ODD.txt","w")
ODD=int(input("Please Enter No:"))
file.write("ODD -")
for i in range(1,ODD,1):
    if i % 2 != 0 :
        file.write(str(i))
file.close()

print("File successfully created.")


# Read file using python
file=open("ODD.txt","r")
lines=file.read()
file.close()
print(lines)
print("Your file is successfully readed.")