# Create a file using python
# file=open("Mydata.txt","w")
# file.write("Hello,python Developer.\n")
# file.write("My name is snehal parmar.\n") 
# file.close()

# print("Your file is successfully created.")


# Read file
file=open("Mydata.txt","r")
lines=file.read()
file.close()
print(lines)
print("Your file is successfully readed.")