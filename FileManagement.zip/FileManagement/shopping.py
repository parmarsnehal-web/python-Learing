import re
from Shoppingclass import shopping

Namepattern="^[A-Za-z]{1,50}$"
Name=input("Please Enter Customer Name:-")
while re.match(Namepattern,Name) == None:
              print("Name is not valid.")  
              Name=input("Please Re-Enter your Name:-")
print("Name is valid.")

# # # create file using python
# file=open("Shopping.txt","w")
no=int(input("How many products You want to Add?- "))
shoppingList=[]
Grandtotal=0


print("=====================================================================================")

for i in range(no):
    print("================================================================================")
    print(f"{i+1}#.")
    print("================================================================================")
    s=shopping()
    # file.write(str(s))
    s.ReadData()
    Grandtotal +=s.Total
    Discount = Grandtotal/10
    NetTotal=Grandtotal-Discount
   
    shoppingList.append(s)



print("=====================================================================================")
print("Customer Name :",Name)
print("=====================================================================================")
print("No\tName\tPrice\tQty\tTotal")
print("=====================================================================================")
count=1
for singleshopping in shoppingList:
    print(f"{count}",end="\t")
    singleshopping.showdata()
    count += 1    
print("=====================================================================================")
print("GrandTotal =",Grandtotal)
print("Discount(10%) =",Discount)
print("Net Total =",NetTotal)
print("Thank for shopping.")

# file.close()
# print("Your file is successfully created.")