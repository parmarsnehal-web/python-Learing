# Regex

import re
# Mobilepattern = "^[0-9]{10}$"
# Mobile=input("Please Enter your Mobile number:-")
# if re.match(Mobilepattern,Mobile) != None:
#     print("Mobile is valid.")
# else:
#     print("Mobile is not valid.")    


# Namepattern = "^[a-zA-Z\\s]{1,50}$"
# Name=input("Please Enter your Name:-")
# if re.match(Namepattern,Name) != None:
#     print("Name is valid.")
# else:
#     print("Name is not valid.")    

Mobilepattern = "^[0-9]{10}$"
Mobile=input("Please Enter your Mobile number:-")
while re.match(Mobilepattern,Mobile) == None:
    print("Mobile is not valid.")  
    Mobile=input("Please Re-Enter your Mobile number:-")
print("Mobile is valid.")
