# try:
#     a=10
#     b=0
#     c=a/b
#     print("The result of division is c:",c)
# except Exception as e:
#     print(e)
#     print("Your program is succesfullly run.")    

try:
    a=[10,20,30,40,50]
    print(a[4])
except Exception as e:
    print(e)
else:
     print("Else block Excuted.")    
finally:
       print("Finally block Excuted.")
print("Array practical is successfully excuted.")    

